from FileController import FileController
from Graph import Graph

f = FileController("input.txt")
g = Graph(f.data)

print(g.topologicalSort())