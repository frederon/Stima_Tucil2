class FileController:

  def __init__(self, fileName):
    f = open(fileName)
    self.data = []
    for l in f.readlines():
      self.data.append(l.rstrip("\n")) 