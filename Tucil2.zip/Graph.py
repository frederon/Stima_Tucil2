class Graph:
  def __init__(self, data):
    self.data = convertToGraph(data)
    self.count = len(data)

  def topologicalSortUtil(self,v,visited,stack): 
      visited[v] = True

      for i in self.data[v]: 
          if visited[i] == False: 
              self.topologicalSortUtil(i,visited,stack) 

      stack.insert(0,v) 

  def topologicalSort(self): 
      visited = {}
      for i in self.data:
        visited[i] = False

      stack = [] 

      for i in self.data: 
          if visited[i] == False: 
              self.topologicalSortUtil(i,visited,stack) 

      return stack

def convertToGraph(lines):
    # make dictionary
    result = {}
    for line in lines:
      line = processLine(line)
      node = line[0]
      result[node] = []

      for line2 in lines:
        line2 = processLine(line2)
        if (node in line2[1:]):
          result[node].append(line2[0])

    return result

def processLine(line):
    # remove spaces
    line = line.replace(" ", "")
    # remove .
    line = line.replace(".", "")
    # convert to list
    line = line.split(",")
    return line